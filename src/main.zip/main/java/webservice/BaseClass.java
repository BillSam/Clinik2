package webservice;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * Created by error on 3/21/18.
 */
@ApplicationPath("/clinicWS")
public class BaseClass extends Application{

}
